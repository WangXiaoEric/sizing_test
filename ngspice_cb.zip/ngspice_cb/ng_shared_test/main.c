/*
Test file for shared ngspice
Copyright Holger Vogt 2017
New BSD license

ngspice library loaded dynamically
simple manual input
*/

/* The original function pointers

ret = ((int (*)(SendChar*, SendStat*, ControlledExit*, SendData*, SendInitData*,
BGThreadRunning*, void*)) ngSpice_Init_handle)(ng_getchar, ng_getstat,
ng_exit, NULL, ng_initdata, ng_thread_runs, NULL);

ret = ((int (*)(char*)) ngSpice_Command_handle)("source ../../examples/adder_mos.cir");

curplot = ((char * (*)()) ngSpice_CurPlot_handle)();

vecarray = ((char ** (*)(char*)) ngSpice_AllVecs_handle)(curplot);

myvec = ((pvector_info (*)(char*)) ngSpice_GVI_handle)(plotvec);

ret = ((int (*)(char**)) ngSpice_Circ_handle)(circarray);

may be replaced by their shortcuts

ret = ngSpice_Init_handle(ng_getchar, ng_getstat,
ng_exit, NULL, ng_initdata, ng_thread_runs, NULL);

ret = ngSpice_Command_handle("source ../../examples/adder_mos.cir");

curplot = ngSpice_CurPlot_handle();

vecarray = ngSpice_AllVecs_handle(curplot);

myvec = ngSpice_GVI_handle(plotvec);

ret = ngSpice_Circ_handle(circarray);
*/



#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>
#include <iostream>

#include <chrono>
#include <ctime>  



#include "../include/sharedspice.h"


#include <dlfcn.h> /* to load libraries*/
#include <unistd.h>
#include <ctype.h>
using namespace std;



typedef void *  funptr_t;

bool no_bg = true;
bool not_yet = true;
bool will_unload = false;
bool error_ngspice = false;

int cieq(register char *p, register char *s);
int ciprefix(const char *p, const char *s);
int getLine(char *prmpt, char *buff, size_t sz);

/* callback functions used by ngspice */
int
ng_getchar(char* outputreturn, int ident, void* userdata);

int
ng_getstat(char* outputreturn, int ident, void* userdata);

int
ng_thread_runs(bool noruns, int ident, void* userdata);

ControlledExit ng_exit;
SendData ng_data;
SendInitData ng_initdata;

//int vecgetnumber = 0;
//double v2dat;
//static bool has_break = false;
char comd[1024];

/* functions exported by ngspice */
// funptr_t ngSpice_Init_handle = NULL;
// funptr_t ngSpice_Command_handle = NULL;
// funptr_t ngSpice_Circ_handle = NULL;
// funptr_t ngSpice_CurPlot_handle = NULL;
// funptr_t ngSpice_AllVecs_handle = NULL;
// funptr_t ngSpice_GVI_handle = NULL;

typedef void *  funptr_t;
int (*ngSpice_Init_handle)(...) = NULL;
int (*ngSpice_Command_handle)(...) = NULL;
int (*ngSpice_Circ_handle) = NULL;
void (*ngSpice_CurPlot_handle) = NULL;
void (*ngSpice_AllVecs_handle) = NULL;
void (*ngSpice_GVI_handle) = NULL;


void * ngdllhandle = NULL; //function pointer.  指向函数的指针

pthread_t mainthread;

int main()
{
    auto start = std::chrono::system_clock::now();
    char *errmsg = NULL, *loadstring;
    int ret;

    char *curplot, *vecname;
    char ** circarray;
    char **vecarray;
    pvector_info myvec;

    printf("****************************\n");
    printf("**  ngspice shared start  **\n");
    printf("****************************\n");


    mainthread = pthread_self();
    // loadstring = "libngspice.so";
    loadstring = "/home/asus/Desktop/sizingtool/ngspice-41/src/.libs/libngspice.so";
    
    ngdllhandle = dlopen(loadstring, RTLD_NOW);
    errmsg = dlerror();
    if (errmsg)
        printf("%s\n", errmsg);
    if (ngdllhandle)
        printf("ngspice.so loaded\n");
    else {
        printf("ngspice.so not loaded !\n");
        getLine("Press any key to exit: ", comd, sizeof(comd));
        return 1;
    }

    *(void**)(&ngSpice_Init_handle) = dlsym(ngdllhandle, "ngSpice_Init"); //
    errmsg = dlerror();
    if (errmsg)
        printf(errmsg);
    *(void**)(&ngSpice_Command_handle) = dlsym(ngdllhandle, "ngSpice_Command");
    errmsg = dlerror();
    if (errmsg)
        printf(errmsg);
    ngSpice_CurPlot_handle = dlsym(ngdllhandle, "ngSpice_CurPlot");
    errmsg = dlerror();
    if (errmsg)
        printf(errmsg);

    ngSpice_AllVecs_handle = dlsym(ngdllhandle, "ngSpice_AllVecs");
    errmsg = dlerror();
    if (errmsg)
        printf(errmsg);
    ngSpice_GVI_handle = dlsym(ngdllhandle, "ngGet_Vec_Info");
    errmsg = dlerror();
    if (errmsg)
        printf(errmsg);

    //(void*)(&ngSpice_Init_handle) = dlsym(ngdllhandle, "ngSpice_Init"); //


    cout << "===================" << endl;



    ret = ngSpice_Init_handle(ng_getchar, ng_getstat,
                               ng_exit, NULL, ng_initdata, ng_thread_runs, NULL);


    error_ngspice = false;
    will_unload = false;
    string comdstr = "source /home/asus/Desktop/sizingtool/ngspice_cb/examples/ac.sp";
    strcpy(comd, comdstr.c_str());

    int MaxLoop = 1000;
    for (int i = 0; i<MaxLoop; i++) {
        /* get command from stdin */
        //getLine("Command: ", comd, sizeof(comd));

        /* return upon 'exit' */
        
        // if (cieq("exit", comd))
        //     break;

        /* If command 'bg_run' is given, ngSpice_Command_handle() will return immediately.
           To guarantee that the primary thread here waits until the run is finished, we
           may set no_bg to 0 already here. Risk: if starting the simulation fails, we never
           may leave the waiting loop. As an alternative callback function ng_thread_runs()
           will set no_bg to 0. This has to happen within the first 200ms waiting time. */
        // if (cieq("bg_run", comd))
        //     no_bg = false;

        ret = ngSpice_Command_handle(comd);

        // curplot = ((char * (*)()) ngSpice_CurPlot_handle)();
        // cout << curplot << endl;

        // vecarray = ((char ** (*)(char*)) ngSpice_AllVecs_handle)(curplot);
        // cout << vecarray << endl;
        // char plotvec[256];
        // myvec = ((pvector_info (*)(char*)) ngSpice_GVI_handle)(plotvec);
        //  cout << myvec << endl;

        if (ret) {
            /* unload now */
            // dlclose(ngdllhandle);
            ngdllhandle = NULL;
            printf("ngspice unloaded\n\n");
            getLine("Press any key to exit: ", comd, sizeof(comd));
            break;
        }
        /* wait until simulation finishes */
//         for (;;) {
// #if defined(__MINGW32__) || defined(_MSC_VER)
//             Sleep(200);
// #else
//             usleep(200000);
// #endif
//             /* after 200ms the the callback function ng_thread_runs() should have
//                set no_bg to 0, otherwise we would not wait for the end of the
//                background thread.*/
//             if (no_bg)
//                 break;
//         }
    }
    auto end = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    std::time_t start_time = std::chrono::system_clock::to_time_t(start);
    std::time_t end_time = std::chrono::system_clock::to_time_t(end);

    std::cout << "1000 circuit NGSPICE simulation by C++: " << std::endl
              << "Start time: " << std::ctime(&start_time) 
              << std::endl;
 
    std::cout << "finished computation at " << std::ctime(&end_time)
              << "elapsed time: " << elapsed_seconds.count() << "s"
              << std::endl;


    return 0;
}


/* Callback function called from bg thread in ngspice to transfer
   any string created by printf or puts. Output to stdout in ngspice is
   preceded by token stdout, same with stderr.*/
int
ng_getchar(char* outputreturn, int ident, void* userdata)
{
    printf("%s\n", outputreturn);
    /* setting a flag if an error message occurred */
    if (ciprefix("stderr Error:", outputreturn))
        error_ngspice = true;
    return 0;
}

/* Callback function called from bg thread in ngspice to transfer
   simulation status (type and progress in percent). */
int
ng_getstat(char* outputreturn, int ident, void* userdata)
{
    printf("%s\n", outputreturn);
    return 0;
}

/* Callback function called from ngspice upon starting (returns true) or
  leaving (returns false) the bg thread. */
int
ng_thread_runs(bool noruns, int ident, void* userdata)
{
    no_bg = noruns;
    if (noruns)
        printf("\nbg not running\n");
    else
        printf("bg running\n\n");

    return 0;
}

/* Callback function called from bg thread in ngspice if fcn controlled_exit()
   is hit. Do not exit, but unload ngspice. */
int
ng_exit(int exitstatus, bool immediate, bool quitexit, int ident, void* userdata)
{
    /*
        if(quitexit) {
            printf("DNote: Returned from quit with exit status %d\n", exitstatus);
        }
        if(immediate) {
            printf("DNote: Unload ngspice\n");
            ((int * (*)(char*)) ngSpice_Command_handle)("quit");
            dlclose(ngdllhandle);
        }

        else {
            printf("DNote: Prepare unloading ngspice\n");
            will_unload = true;
        }
    */
    return exitstatus;

}

/* Callback function called from bg thread in ngspice once per accepted data point */
int
ng_data(pvecvaluesall vdata, int numvecs, int ident, void* userdata)
{
    /*
        int *ret;

        v2dat = vdata->vecsa[vecgetnumber]->creal;
        if (!has_break && (v2dat > 0.5)) {
        // using signal SIGTERM by sending to main thread, alterp() then is run from the main thread,
        //(not on Windows though!)
    #ifndef _MSC_VER
            if (testnumber == 4)
                pthread_kill(mainthread, SIGTERM);
    #endif
            has_break = true;
        // leave bg thread for a while to allow halting it from main
    #if defined(__MINGW32__) || defined(_MSC_VER)
            Sleep (100);
    #else
            usleep (100000);
    #endif
    //        ret = ((int * (*)(char*)) ngSpice_Command_handle)("bg_halt");
        }
    */
    return 0;
}


/* Callback function called from bg thread in ngspice once upon intialization
   of the simulation vectors)*/
int
ng_initdata(pvecinfoall intdata, int ident, void* userdata)
{
    /*
        int i;
        int vn = intdata->veccount;
        for (i = 0; i < vn; i++) {
            printf("Vector: %s\n", intdata->vecs[i]->vecname);
            // find the location of V(2)
            if (cieq(intdata->vecs[i]->vecname, "V(2)"))
                vecgetnumber = i;
        }
    */
    return 0;
}

/* Unify LINUX and Windows dynamic library handling:
   Add functions dlopen, dlsym, dlerror, dlclose to Windows by
   tranlating to Windows API functions.
*/
// #if defined(__MINGW32__) ||  defined(_MSC_VER)

// void *dlopen(const char *name,int type)
// {
//     return LoadLibrary((LPCSTR)name);
// }

// funptr_t dlsym(void *hDll, const char *funcname)
// {
//     return GetProcAddress(hDll, funcname);
// }

// char *dlerror(void)
// {
//     LPVOID lpMsgBuf;
//     char * testerr;
//     DWORD dw = GetLastError();

//     FormatMessage(
//         FORMAT_MESSAGE_ALLOCATE_BUFFER |
//         FORMAT_MESSAGE_FROM_SYSTEM |
//         FORMAT_MESSAGE_IGNORE_INSERTS,
//         NULL,
//         dw,
//         MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
//         (LPTSTR) &lpMsgBuf,
//         0,
//         NULL
//     );
//     testerr = (char*)lpMsgBuf;
//     strcpy(errstr,lpMsgBuf);
//     LocalFree(lpMsgBuf);
//     if (ciprefix("Der Vorgang wurde erfolgreich beendet.", errstr))
//         return NULL;
//     else
//         return errstr;
// }

// int dlclose (void *lhandle)
// {
//     return (int)FreeLibrary(lhandle);
// }
// #endif

/* Case insensitive str eq.
   Like strcasecmp( ) XXX */
int
cieq(register char *p, register char *s)
{
    while (*p) {
        if ((isupper(*p) ? tolower(*p) : *p) !=
                (isupper(*s) ? tolower(*s) : *s))
            return(false);
        p++;
        s++;
    }
    return (*s ? false : true);
}

/* Case insensitive prefix. */
int
ciprefix(const char *p, const char *s)
{
    while (*p) {
        if ((isupper(*p) ? tolower(*p) : *p) !=
                (isupper(*s) ? tolower(*s) : *s))
            return(false);
        p++;
        s++;
    }
    return (true);
}

/* read a line from console input
   source:
   https://stackoverflow.com/questions/4023895/how-to-read-string-entered-by-user-in-c
   */
#define OK       0
#define NO_INPUT 1
#define TOO_LONG 2
int
getLine(char *prmpt, char *buff, size_t sz)
{
    int ch, extra;

    // Get line with buffer overrun protection.
    if (prmpt != NULL) {
        printf("%s", prmpt);
        fflush(stdout);
    }
    if (fgets(buff, sz, stdin) == NULL)
        return NO_INPUT;

    // If it was too long, there'll be no newline. In that case, we flush
    // to end of line so that excess doesn't affect the next call.
    if (buff[strlen(buff) - 1] != '\n') {
        extra = 0;
        while (((ch = getchar()) != '\n') && (ch != EOF))
            extra = 1;
        return (extra == 1) ? TOO_LONG : OK;
    }

    // Otherwise remove newline and give string back to caller.
    buff[strlen(buff) - 1] = '\0';
    return OK;
}
